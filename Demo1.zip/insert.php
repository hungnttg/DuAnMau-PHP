<?php
$s="localhost";
$u="root";
$p="";
$db="apr";
//tao ket noi
$con = new mysqli($s,$u,$p,$db);
//kiem tra ket noi
if($con->connect_error)
{
    die("Loi ket noi: ".$con->connect_error);
}
//cau lenh
$sql="insert into KhachHang (ho,ten,email) values ('Nguyen Van ','An','an@gmail.com')";
if($con->query($sql)===true)
{
    echo "insert thaanh cong";
}
else
{
    echo "Loi: ". $con->error;
}
?>